const {
    Client,
    GatewayIntentBits,
    PermissionsBitField
} = require('discord.js');

const fs = require('fs');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

const config = require('./config/config');

client.login(config.bot.token);

const {
    checkVipServers,
    registerSlashCommands
} = require('./functions/allfunc');

client.once('ready', () => {
    console.log(`✅ تم تسجيل الدخول باسم: ${client.user.tag}`);
    checkVipServers();
    registerSlashCommands();
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    if (interaction.commandName === 'set_auto_line') {

        await interaction.deferReply({ ephemeral: true });

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.editReply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
        }

        const autolineChannel = interaction.options.getChannel('channel');
        if (!autolineChannel) {
            return interaction.editReply({ content: '❌ الرجاء تحديد قناة صحيحة.' });
        }

        const filePath = './database/autoline.json';
        let autoLineData = {};

        if (fs.existsSync(filePath)) {
            autoLineData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        }

        if (!autoLineData.channels) {
            autoLineData.channels = [];
        }

        if (!autoLineData.channels.includes(autolineChannel.id)) {
            autoLineData.channels.push(autolineChannel.id);

            fs.writeFileSync(filePath, JSON.stringify(autoLineData, null, 4));

            return interaction.editReply({ content: `✅ تم تعيين القناة ${autolineChannel.name} لإرسال الرسائل التلقائية.` });
        } else {
            return interaction.editReply({ content: '⚠️ هذه القناة مضافة بالفعل للرسائل التلقائية.' });
        }
    }

    if (interaction.commandName === 'set_auto_react') {

        await interaction.deferReply({ ephemeral: true });

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.editReply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.' });
        }

        const autoreactChannel = interaction.options.getChannel('channel');
        const emoji = interaction.options.getString('emoji');

        if (!autoreactChannel || !emoji) {
            return interaction.editReply({ content: '❌ الرجاء تحديد كل من القناة والإيموجي.' });
        }

        if (!emoji.match(/<a?:\w+:\d+>|[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{2300}-\u{23FF}\u{2B50}]/u)) {
            return interaction.editReply({ content: '❌ الإيموجي غير صالح، الرجاء استخدام إيموجي صالح.' });
        }

        const filePath = './database/autoreact.json';
        let autoReactData = {};

        if (fs.existsSync(filePath)) {
            autoReactData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        }

        if (!autoReactData.channels) {
            autoReactData.channels = [];
        }

        const channelIndex = autoReactData.channels.findIndex(item => item.channelId === autoreactChannel.id);

        if (channelIndex === -1) {
            autoReactData.channels.push({ channelId: autoreactChannel.id, emoji: emoji });
        } else {
            autoReactData.channels[channelIndex].emoji = emoji;
        }

        fs.writeFileSync(filePath, JSON.stringify(autoReactData, null, 4));

        return interaction.editReply({ content: `✅ سيتم الآن التفاعل بـ ${emoji} في القناة ${autoreactChannel.name}.` });
    }
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    const filePath = './database/autoline.json';
    if (!fs.existsSync(filePath)) return;

    const autoLineData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    if (!autoLineData.channels || !autoLineData.channels.includes(message.channel.id)) {
        return;
    }

    const lineImageUrl = config.bot.lineURL;
    try {
        await message.channel.send({
            files: [lineImageUrl]
        });
    } catch (err) {
        console.error('Failed to send image:', err);
    }
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    const filePath = './database/autoreact.json';
    if (!fs.existsSync(filePath)) return;

    const autoReactData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    if (!autoReactData.channels) return;

    const channelData = autoReactData.channels.find(item => item.channelId === message.channel.id);

    if (channelData) {
        try {
            await message.react(channelData.emoji);
        } catch (err) {
            console.error('Failed to react with emoji:', err);
        }
    }
});