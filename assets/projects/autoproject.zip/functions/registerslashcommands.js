const { REST } = require('@discordjs/rest');
const { Routes, ApplicationCommandOptionType } = require('discord.js');
const config = require('../config/config');

const commands = [
  {
    name: 'set_auto_line',
    description: 'set auto line channels',
    options: [
        {
            name: 'channel',
            description: 'channel',
            type: ApplicationCommandOptionType.Channel,
            required: true
        }
    ]
  },
  {
    name: 'set_auto_react',
    description: 'set auto react channels + emoji',
    options: [
        {
            name: 'channel',
            description: 'channel',
            type: ApplicationCommandOptionType.Channel,
            required: true
        },
        {
            name: 'emoji',
            description: 'emoji',
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ]
  }
];

async function registerSlashCommands() {
    const rest = new REST({ version: '10' }).setToken(config.bot.token);

    try {
        console.log('Started refreshing application (/) commands.');

        const existingCommands = await rest.get(Routes.applicationCommands(config.bot.id));

        for (const command of existingCommands) {
            await rest.delete(Routes.applicationCommand(config.bot.id, command.id));
            console.log(`Deleted command: ${command.name}`);
        }

        console.log('Successfully deleted old commands. Adding new commands...');

        await rest.put(Routes.applicationCommands(config.bot.id), { body: commands });

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error refreshing application (/) commands:', error);
    }
}

module.exports = { registerSlashCommands };