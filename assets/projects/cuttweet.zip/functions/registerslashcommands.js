const { REST } = require('@discordjs/rest');
const { Routes, ApplicationCommandOptionType } = require('discord.js');
const config = require('../config/config');

const commands = [
  {
    name: 'كت_تويت',
    description: 'ارسال رساله كت تويت.'
  },
  {
    name: 'إضافه_كت_تويت',
    description: 'إضافه كت تويت للداتا (للادمنز فقط).',
    options: [
        {
            name: 'message',
            description: 'حط كلام كت تويت هنا.',
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ]
  }
];

async function registerSlashCommands() {
    const rest = new REST({ version: '10' }).setToken(config.bot.token);

    try {
        console.log('Started refreshing application (/) commands.');

        const existingCommands = await rest.get(Routes.applicationCommands(config.bot.id));

        for (const command of existingCommands) {
            await rest.delete(Routes.applicationCommand(config.bot.id, command.id));
            console.log(`Deleted command: ${command.name}`);
        }

        console.log('Successfully deleted old commands. Adding new commands...');

        await rest.put(Routes.applicationCommands(config.bot.id), { body: commands });

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error('Error refreshing application (/) commands:', error);
    }
}

module.exports = { registerSlashCommands };