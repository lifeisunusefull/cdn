const vipServers = ["حط اي دي سيرفر حقك هنا"];

async function checkVipServers(client) {
    for (const guild of client.guilds.cache.values()) {
        if (!vipServers.includes(guild.id)) {
            console.log(`Leaving non-VIP server: ${guild.name} (${guild.id})`);
            await guild.leave();
        } else {
            console.log(`Staying in VIP server: ${guild.name} (${guild.id})`);
        }
    }
}

module.exports = { checkVipServers };