const { checkVipServers } = require('./checkVipServers');
const { registerSlashCommands } = require('./registerslashcommands');

module.exports = {
    checkVipServers,
    registerSlashCommands
};