module.exports = {
    bot: {
        token: "", // توكن بوت هون
        id: "", // اي دي بوت هون
        prefix: "", // هنا تحط بريفيكس البوت
    }
};