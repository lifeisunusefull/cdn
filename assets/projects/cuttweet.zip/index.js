const {
    Client,
    GatewayIntentBits,
    PermissionsBitField
} = require('discord.js');

const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

const config = require('./config/config');

client.login(config.bot.token);

const {
    checkVipServers,
    registerSlashCommands
} = require('./functions/allfunc');

client.once('ready', () => {
    console.log(`✅ تم تسجيل الدخول باسم: ${client.user.tag}`);
    checkVipServers();
    registerSlashCommands();
});

const messagesFile = path.join(__dirname, './database/message.json');
let messages = [];

if (fs.existsSync(messagesFile)) {
    messages = JSON.parse(fs.readFileSync(messagesFile, 'utf8'));
}

client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    if (interaction.commandName === 'كت_تويت') {
        if (messages.length === 0) {
            return interaction.reply({ content: '❌ لا توجد رسائل كت تويت متاحة.', ephemeral: true });
        }

        const randomMessage = messages[Math.floor(Math.random() * messages.length)];

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📝 كت تويت')
            .setDescription(`>>> ${randomMessage}`)
            .setFooter({ text: `طلب بواسطة: ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }

    if (interaction.commandName === 'إضافه_كت_تويت') {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.', ephemeral: true });
        }

        const newMessage = interaction.options.getString('message');
        messages.push(newMessage);

        fs.writeFileSync(messagesFile, JSON.stringify(messages, null, 2));

        return interaction.reply({ content: '✅ تم إضافة كت تويت بنجاح!', ephemeral: true });
    }
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (message.content.startsWith(config.bot.prefix + 'كت')) {
        if (cutTweetMessages.length === 0) {
            return message.channel.send('❌ لا توجد أي رسائل كت تويت متاحة!');
        }

        const randomMessage = cutTweetMessages[Math.floor(Math.random() * cutTweetMessages.length)];
        const embed = new EmbedBuilder()
            .setColor('#00AAFF')
            .setTitle('🎭 كت تويت')
            .setDescription(randomMessage)
            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() || client.user.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    }
});